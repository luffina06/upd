
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<!-- <div class="menu-bar">
        <a href="dashboard.php" class="active">Dashboard</a>
        <a href="dtr.php">Upload DTR</a>
        <a href="#"></a>
        <a  b href="logout.php">Logout</a>
</div> -->

<div class="topnav" id="myTopnav">
  <a href="logout.php">Log Out</a>
</div>
 
<div class="sidebarr">
    <a href="dashboard.php" class="active">Dashboard</a>
    <a href="dtr.php">DTR</a>
    <!-- <a href="#contact">Contact</a>
    <a href="#about">About</a> -->
</div>
